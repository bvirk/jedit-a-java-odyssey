$(function() {
	$('pre').addClass('prettyprint'); 
	$('code').addClass('language-java'); 
});
                                                                                 