<div class="wrapper">
<header>&nbsp;</header>
<div id="bufsw">
<label for="fileSelect">▢&nbsp;</label><select id="fileSelect"></select>
</div>
  <section> 
  <article>
<!--include ${sourcefile} -->
  </article>
  </section>
  <footer><div class="footleft">&#9666;</div><div class="footright">&#9656;</div></footer>
</div>
